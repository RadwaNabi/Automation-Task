const { chromium } = require('playwright');

(async () => {
    const browser = await chromium.launch({ headless: false });
    const page = await browser.newPage();
    await page.goto('https://www.saucedemo.com');

    // Login
    await page.fill('#user-name', 'standard_user');
    await page.fill('#password', 'secret_sauce');
    await page.click('#login-button');

    // Sorting the products
    await page.selectOption('.product_sort_container', 'lohi');

    // Add products from landing page
    await page.click('button[name="add-to-cart-sauce-labs-backpack"]');
    await page.click('button[name="add-to-cart-sauce-labs-bike-light"]');

    // Remove product from landing page
    await page.click('button[name="remove-sauce-labs-backpack"]');

    // View cart products
    await page.click('.shopping_cart_link');

    // Fill Checkout form
    await page.click('.checkout_button');
    await page.fill('#first-name', 'John');
    await page.fill('#last-name', 'Doe');
    await page.fill('#postal-code', '12345');
    await page.click('.continue_button');

    // Canceling checkout
    await page.click('.cancel_button');

    // Remove products from cart
    await page.click('.shopping_cart_link');
    await page.click('button[name="remove-sauce-labs-bike-light"]');

    // Checkout of empty cart
    await page.click('.shopping_cart_link');
    await page.click('.checkout_button');

    // Logout
    await page.click('#react-burger-menu-btn');
    await page.click('#logout_sidebar_link');

    await browser.close();
})();