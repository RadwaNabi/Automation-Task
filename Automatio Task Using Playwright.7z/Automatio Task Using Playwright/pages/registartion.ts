import { Locator, Page } from "@playwright/test";

export class Registration{



page:Page
    private readonly FirstName:Locator;
    private readonly LastName:Locator;
    private readonly DateOfBirth:Locator;
    private readonly Address:Locator;
    private readonly Postcode:Locator;
    private readonly City:Locator;
    private readonly State:Locator;
    private readonly Country:Locator;
    private readonly Phone:Locator;
    private readonly EmailAddress:Locator;
    private readonly Password:Locator;
    private readonly RegisterBtn:Locator;

    //assign value to the variable here or in the constructor only

constructor(page){
this.page=page;
this.FirstName=page.getByPlaceholder('First name *');
this.LastName=page.getByPlaceholder('Your last name *');
this.DateOfBirth=page.getByPlaceholder('Your Date of birth *');
this.Address=page.locator('[data-test="address"]');
this.Postcode=page.locator('[data-test="postcode"]');
this.City=page.getByPlaceholder('Your City *');
this.State=page.getByTestId('country');
this.Country=page.locator('[data-test="country"]');
this.Phone=page.locator('[data-test="phone"]');
this.EmailAddress=page.locator('[data-test="email"]');
this.Password=page.locator('[data-test="password"]');
this.RegisterBtn=page.locator('[data-test="register-submit"]');

}    

async Register1(FirstName:string,LastName:string,DateOfBirth:string,
    Address:string,postcode:string,City:string,State:string){
    await this.FirstName.fill(FirstName);
    await this.LastName.fill(LastName);
    await this.DateOfBirth.fill(DateOfBirth);
    await this.Address.fill(Address);
    await this.Postcode.fill(postcode);
    await this.City.fill(City);
    await this.State.fill(State);

    


}
async Register2(country:string,phone:string,EmailAddress:string,password:string,){
    await this.Country.fill(country);
    await this.Phone.fill(phone);
    await this.EmailAddress.fill(EmailAddress);
    await this.Password.fill(password);
    await this.RegisterBtn.click();
}
}
